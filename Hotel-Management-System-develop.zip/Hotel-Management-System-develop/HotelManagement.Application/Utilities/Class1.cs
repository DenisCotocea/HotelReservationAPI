﻿namespace HotelManagement.Application.Utilities
{
    public class Class1
    {

    }
}