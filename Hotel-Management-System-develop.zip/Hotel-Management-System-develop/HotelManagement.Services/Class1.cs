﻿namespace HotelManagement.Services
{
    public class Class1
    {

    }
}