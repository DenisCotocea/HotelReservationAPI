﻿namespace HotelManagement.Core
{
    public class Class1
    {

    }
}