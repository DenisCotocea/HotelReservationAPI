﻿using HotelManagement.Core.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagement.Core.DTOs
{
    public class RoleDTO
    {
        public Roles RoleName { get; set; }
    }
}
