﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagement.Core.DTOs
{
    public class ResetPasswordDTO
    {
        public string Email { get; set; }
    }
}
