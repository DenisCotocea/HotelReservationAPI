﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagement.Core.DTOs
{
    public class AddRoomDto
    {
        public string RoomNo { get; set; }
        public bool IsBooked { get; set; }

    }
}
