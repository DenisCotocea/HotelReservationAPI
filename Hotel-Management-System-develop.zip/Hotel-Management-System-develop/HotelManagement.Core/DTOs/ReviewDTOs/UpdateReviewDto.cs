﻿using HotelManagement.Core.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagement.Core.DTOs.ReviewDTOs
{
    public class UpdateReviewDto
    {
        public string Comment { get; set; }
    }
}
