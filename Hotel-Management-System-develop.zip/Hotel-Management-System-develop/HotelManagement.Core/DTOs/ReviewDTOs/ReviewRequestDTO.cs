﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelManagement.Core.DTOs.ReviewDTOs
{
    public class ReviewRequestDTO
    {
        public string Comment { get; set; }
    }
}
