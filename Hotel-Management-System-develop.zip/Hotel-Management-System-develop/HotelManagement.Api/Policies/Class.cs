﻿namespace HotelManagement.Api.Policies
{
    public class Class
    {
    }
}
