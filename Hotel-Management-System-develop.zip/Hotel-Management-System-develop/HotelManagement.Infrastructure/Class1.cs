﻿namespace HotelManagement.Infrastructure
{
    public class Class1
    {

    }
}