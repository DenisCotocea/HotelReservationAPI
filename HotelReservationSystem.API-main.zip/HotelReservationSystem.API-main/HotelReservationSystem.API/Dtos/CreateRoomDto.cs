﻿namespace HotelReservationSystem.API.Dtos
{
    public class CreateRoomDto
    {
        public string Type { get; set; }
        public decimal Price { get; set; }
    }
}
