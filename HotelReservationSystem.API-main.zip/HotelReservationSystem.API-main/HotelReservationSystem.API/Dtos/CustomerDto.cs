﻿namespace HotelReservationSystem.API.Dtos
{
    public class CustomerDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
